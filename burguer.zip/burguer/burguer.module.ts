import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { BurguerPage } from './burguer';



@NgModule({
  declarations: [
    BurguerPage,
  ],
  imports: [
   IonicPageModule.forChild(BurguerPage),
  ],
})
export class BurguerPageModule {}